const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");
const sessions = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true });

function createDB() {
  if (!fs.existsSync(DB_PATH)) {
    const now = new Date().toISOString();
    const db = {
      users: [],
      clothes: [
        {
          id: crypto.randomUUID(),
          ownerId: "demo",
          ownerName: "Clic Mod",
          name: "Jaqueta jeans",
          size: "M",
          condition: "Ótimo",
          type: "Venda",
          price: 45,
          description: "Jaqueta em bom estado para ganhar uma nova vida.",
          imageData: "",
          createdAt: now,
          interests: []
        },
        {
          id: crypto.randomUUID(),
          ownerId: "demo",
          ownerName: "Clic Mod",
          name: "Camisa social",
          size: "G",
          condition: "Bom",
          type: "Troca",
          price: 0,
          description: "Camisa para trocar por outra peça casual.",
          imageData: "",
          createdAt: now,
          interests: []
        },
        {
          id: crypto.randomUUID(),
          ownerId: "demo",
          ownerName: "Clic Mod",
          name: "Moletom lilás",
          size: "P",
          condition: "Ótimo",
          type: "Doação",
          price: 0,
          description: "Moletom conservado para doação.",
          imageData: "",
          createdAt: now,
          interests: []
        }
      ]
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  }
}

function readDB() {
  createDB();
  return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

function sendJSON(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 8 * 1024 * 1024) {
        reject(new Error("Arquivo muito grande. Use uma imagem menor."));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error("JSON inválido."));
      }
    });
  });
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex");
  return { salt, hash };
}

function checkPassword(password, user) {
  const result = hashPassword(password, user.salt);
  return result.hash === user.passwordHash;
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    points: user.points || 0,
    createdAt: user.createdAt
  };
}

function getUserFromRequest(req) {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "");
  if (!token || !sessions.has(token)) return null;

  const db = readDB();
  return db.users.find(user => user.id === sessions.get(token)) || null;
}

function requireAuth(req, res) {
  const user = getUserFromRequest(req);
  if (!user) {
    sendJSON(res, 401, { error: "Faça login para continuar." });
    return null;
  }
  return user;
}

function mimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const types = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml"
  };
  return types[ext] || "application/octet-stream";
}

function serveStatic(req, res, pathname) {
  let filePath = pathname === "/" ? path.join(PUBLIC_DIR, "index.html") : path.join(PUBLIC_DIR, pathname);
  const normalized = path.normalize(filePath);

  if (!normalized.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Acesso negado");
  }

  fs.readFile(normalized, (err, content) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Arquivo não encontrado");
    }
    res.writeHead(200, { "Content-Type": mimeType(normalized) });
    res.end(content);
  });
}

async function handleAPI(req, res, url) {
  const method = req.method;
  const pathname = url.pathname;

  try {
    if (method === "GET" && pathname === "/api/health") {
      return sendJSON(res, 200, { status: "ok", app: "Clic Mod" });
    }

    if (method === "POST" && pathname === "/api/register") {
      const { name, email, password } = await readBody(req);
      if (!name || !email || !password) return sendJSON(res, 400, { error: "Preencha nome, e-mail e senha." });
      if (password.length < 4) return sendJSON(res, 400, { error: "A senha deve ter pelo menos 4 caracteres." });

      const db = readDB();
      const normalizedEmail = String(email).trim().toLowerCase();
      if (db.users.some(user => user.email === normalizedEmail)) {
        return sendJSON(res, 409, { error: "Este e-mail já está cadastrado." });
      }

      const passwordInfo = hashPassword(password);
      const user = {
        id: crypto.randomUUID(),
        name: String(name).trim(),
        email: normalizedEmail,
        passwordHash: passwordInfo.hash,
        salt: passwordInfo.salt,
        points: 0,
        createdAt: new Date().toISOString()
      };

      db.users.push(user);
      saveDB(db);

      const token = crypto.randomBytes(32).toString("hex");
      sessions.set(token, user.id);

      return sendJSON(res, 201, { message: "Conta criada com sucesso.", token, user: publicUser(user) });
    }

    if (method === "POST" && pathname === "/api/login") {
      const { email, password } = await readBody(req);
      if (!email || !password) return sendJSON(res, 400, { error: "Preencha e-mail e senha." });

      const db = readDB();
      const user = db.users.find(user => user.email === String(email).trim().toLowerCase());
      if (!user || !checkPassword(password, user)) {
        return sendJSON(res, 401, { error: "E-mail ou senha incorretos." });
      }

      const token = crypto.randomBytes(32).toString("hex");
      sessions.set(token, user.id);

      return sendJSON(res, 200, { message: "Login realizado com sucesso.", token, user: publicUser(user) });
    }

    if (method === "GET" && pathname === "/api/me") {
      const user = requireAuth(req, res);
      if (!user) return;
      return sendJSON(res, 200, { user: publicUser(user) });
    }

    if (method === "GET" && pathname === "/api/clothes") {
      const db = readDB();
      const search = String(url.searchParams.get("search") || "").toLowerCase();
      const type = String(url.searchParams.get("type") || "");

      let clothes = db.clothes.slice();

      if (search) {
        clothes = clothes.filter(item =>
          item.name.toLowerCase().includes(search) ||
          item.description.toLowerCase().includes(search) ||
          item.condition.toLowerCase().includes(search) ||
          item.size.toLowerCase().includes(search)
        );
      }

      if (type) {
        clothes = clothes.filter(item => item.type === type);
      }

      clothes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      return sendJSON(res, 200, { clothes });
    }

    if (method === "POST" && pathname === "/api/clothes") {
      const user = requireAuth(req, res);
      if (!user) return;

      const body = await readBody(req);
      const { name, size, condition, type, price, description, imageData } = body;

      if (!name || !size || !condition || !type || !description) {
        return sendJSON(res, 400, { error: "Preencha todos os campos principais." });
      }

      if (!["Venda", "Troca", "Doação"].includes(type)) {
        return sendJSON(res, 400, { error: "Tipo inválido." });
      }

      if (type === "Venda" && Number(price) <= 0) {
        return sendJSON(res, 400, { error: "Para venda, informe um preço maior que zero." });
      }

      const db = readDB();
      const dbUser = db.users.find(u => u.id === user.id);

      const item = {
        id: crypto.randomUUID(),
        ownerId: user.id,
        ownerName: user.name,
        name: String(name).trim(),
        size,
        condition,
        type,
        price: type === "Venda" ? Number(price) : 0,
        description: String(description).trim(),
        imageData: imageData || "",
        createdAt: new Date().toISOString(),
        interests: []
      };

      db.clothes.push(item);

      if (dbUser) {
        dbUser.points = (dbUser.points || 0) + 10;
      }

      saveDB(db);
      return sendJSON(res, 201, {
        message: "Roupa publicada com sucesso. Você ganhou 10 pontos sustentáveis.",
        item,
        user: publicUser(dbUser)
      });
    }

    if (method === "GET" && pathname === "/api/my-clothes") {
      const user = requireAuth(req, res);
      if (!user) return;

      const db = readDB();
      const clothes = db.clothes
        .filter(item => item.ownerId === user.id)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      return sendJSON(res, 200, { clothes });
    }

    const interestMatch = pathname.match(/^\/api\/clothes\/([^/]+)\/interest$/);
    if (method === "POST" && interestMatch) {
      const user = requireAuth(req, res);
      if (!user) return;

      const id = interestMatch[1];
      const db = readDB();
      const item = db.clothes.find(item => item.id === id);

      if (!item) return sendJSON(res, 404, { error: "Roupa não encontrada." });
      if (item.ownerId === user.id) return sendJSON(res, 400, { error: "Você não pode demonstrar interesse na própria roupa." });

      const exists = item.interests.some(i => i.userId === user.id);
      if (!exists) {
        item.interests.push({
          userId: user.id,
          userName: user.name,
          createdAt: new Date().toISOString()
        });
        saveDB(db);
      }

      return sendJSON(res, 200, { message: `Interesse registrado em "${item.name}".`, item });
    }

    const deleteMatch = pathname.match(/^\/api\/clothes\/([^/]+)$/);
    if (method === "DELETE" && deleteMatch) {
      const user = requireAuth(req, res);
      if (!user) return;

      const id = deleteMatch[1];
      const db = readDB();
      const index = db.clothes.findIndex(item => item.id === id);

      if (index === -1) return sendJSON(res, 404, { error: "Roupa não encontrada." });
      if (db.clothes[index].ownerId !== user.id) return sendJSON(res, 403, { error: "Você só pode apagar seus próprios anúncios." });

      db.clothes.splice(index, 1);
      saveDB(db);

      return sendJSON(res, 200, { message: "Anúncio removido com sucesso." });
    }

    if (method === "GET" && pathname === "/api/stats") {
      const db = readDB();
      const sales = db.clothes.filter(item => item.type === "Venda");
      return sendJSON(res, 200, {
        totalUsers: db.users.length,
        totalClothes: db.clothes.length,
        sales: sales.length,
        exchanges: db.clothes.filter(item => item.type === "Troca").length,
        donations: db.clothes.filter(item => item.type === "Doação").length,
        estimatedCommission: sales.reduce((sum, item) => sum + item.price * 0.05, 0)
      });
    }

    return sendJSON(res, 404, { error: "Rota não encontrada." });
  } catch (error) {
    return sendJSON(res, 400, { error: error.message || "Erro inesperado." });
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (url.pathname.startsWith("/api/")) {
    return handleAPI(req, res, url);
  }

  return serveStatic(req, res, decodeURIComponent(url.pathname));
});

createDB();
server.listen(PORT, () => {
  console.log(`Clic Mod rodando em http://localhost:${PORT}`);
});
