const API = "";

let token = localStorage.getItem("clicmod_token") || "";
let usuario = JSON.parse(localStorage.getItem("clicmod_usuario") || "null");

function alternarMenu() {
  document.getElementById("menu").classList.toggle("aberto");
}

function mostrarTela(id) {
  document.querySelectorAll(".tela").forEach(tela => tela.classList.remove("ativa"));
  document.getElementById(id).classList.add("ativa");

  const menu = document.getElementById("menu");
  if (menu) menu.classList.remove("aberto");

  if (id === "feed") carregarRoupas();
  if (id === "perfil") carregarPerfil();
  if (id === "inicio") carregarIndicadores();
}

function toast(mensagem) {
  const el = document.getElementById("toast");
  el.textContent = mensagem;
  el.classList.add("ativo");
  setTimeout(() => el.classList.remove("ativo"), 3000);
}

function authHeaders(extra = {}) {
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

async function respostaJSON(resposta) {
  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(dados.error || "Erro na requisição.");
  return dados;
}

async function cadastrar() {
  const name = document.getElementById("cadNome").value.trim();
  const email = document.getElementById("cadEmail").value.trim();
  const password = document.getElementById("cadSenha").value.trim();

  try {
    const resposta = await fetch(`${API}/api/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password })
    });

    const dados = await respostaJSON(resposta);
    token = dados.token;
    usuario = dados.user;

    localStorage.setItem("clicmod_token", token);
    localStorage.setItem("clicmod_usuario", JSON.stringify(usuario));

    toast("Conta criada com sucesso!");
    mostrarTela("feed");
  } catch (erro) {
    toast(erro.message);
  }
}

async function login() {
  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginSenha").value.trim();

  try {
    const resposta = await fetch(`${API}/api/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const dados = await respostaJSON(resposta);
    token = dados.token;
    usuario = dados.user;

    localStorage.setItem("clicmod_token", token);
    localStorage.setItem("clicmod_usuario", JSON.stringify(usuario));

    toast("Login realizado com sucesso!");
    mostrarTela("feed");
  } catch (erro) {
    toast(erro.message);
  }
}

function sair() {
  token = "";
  usuario = null;
  localStorage.removeItem("clicmod_token");
  localStorage.removeItem("clicmod_usuario");
  toast("Você saiu da conta.");
  carregarPerfil();
}

function controlarPreco() {
  const tipo = document.getElementById("roupaTipo").value;
  const preco = document.getElementById("roupaPreco");

  if (tipo === "Venda") {
    preco.disabled = false;
    preco.placeholder = "Ex: 35";
  } else {
    preco.value = "";
    preco.disabled = true;
    preco.placeholder = "Sem preço";
  }
}

async function arquivoParaBase64(arquivo) {
  if (!arquivo) return "";

  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = () => resolve(leitor.result);
    leitor.onerror = () => reject(new Error("Erro ao ler imagem."));
    leitor.readAsDataURL(arquivo);
  });
}

async function carregarRoupas() {
  const lista = document.getElementById("listaRoupas");
  lista.innerHTML = "<p>Carregando roupas...</p>";

  const busca = document.getElementById("busca")?.value || "";
  const tipo = document.getElementById("filtroTipo")?.value || "";

  const params = new URLSearchParams();
  if (busca) params.set("search", busca);
  if (tipo) params.set("type", tipo);

  try {
    const resposta = await fetch(`${API}/api/clothes?${params.toString()}`);
    const dados = await respostaJSON(resposta);

    if (!dados.clothes.length) {
      lista.innerHTML = "<p>Nenhuma roupa encontrada.</p>";
      return;
    }

    lista.innerHTML = dados.clothes.map(item => {
      const preco = item.type === "Venda" ? `R$ ${Number(item.price).toFixed(2)}` : item.type;
      const imagem = item.imageData
        ? `<img class="foto-roupa" src="${item.imageData}" alt="${escapeHTML(item.name)}">`
        : `<div class="sem-foto">👕</div>`;

      return `
        <article class="card-roupa">
          ${imagem}
          <div class="info-roupa">
            <span class="badge">${item.type}</span>
            <h3>${escapeHTML(item.name)}</h3>
            <p><strong>Tamanho:</strong> ${escapeHTML(item.size)}</p>
            <p><strong>Estado:</strong> ${escapeHTML(item.condition)}</p>
            <p><strong>Dono:</strong> ${escapeHTML(item.ownerName || "Usuário")}</p>
            <p>${escapeHTML(item.description)}</p>
            <p class="preco">${preco}</p>
            <button class="btn primario cheio" onclick="registrarInteresse('${item.id}')">Tenho interesse</button>
          </div>
        </article>
      `;
    }).join("");
  } catch (erro) {
    lista.innerHTML = `<p>${erro.message}</p>`;
  }
}

async function publicarRoupa() {
  if (!token) {
    toast("Faça login para publicar uma roupa.");
    mostrarTela("login");
    return;
  }

  const arquivo = document.getElementById("roupaImagem").files[0];

  try {
    const imageData = await arquivoParaBase64(arquivo);

    const body = {
      name: document.getElementById("roupaNome").value.trim(),
      size: document.getElementById("roupaTamanho").value,
      condition: document.getElementById("roupaEstado").value,
      type: document.getElementById("roupaTipo").value,
      price: document.getElementById("roupaPreco").value || 0,
      description: document.getElementById("roupaDescricao").value.trim(),
      imageData
    };

    const resposta = await fetch(`${API}/api/clothes`, {
      method: "POST",
      headers: authHeaders({ "Content-Type": "application/json" }),
      body: JSON.stringify(body)
    });

    const dados = await respostaJSON(resposta);

    if (dados.user) {
      usuario = dados.user;
      localStorage.setItem("clicmod_usuario", JSON.stringify(usuario));
    }

    limparFormulario();
    toast(dados.message);
    mostrarTela("feed");
  } catch (erro) {
    toast(erro.message);
  }
}

function limparFormulario() {
  document.getElementById("roupaImagem").value = "";
  document.getElementById("roupaNome").value = "";
  document.getElementById("roupaTamanho").value = "";
  document.getElementById("roupaEstado").value = "";
  document.getElementById("roupaTipo").value = "Venda";
  document.getElementById("roupaPreco").value = "";
  document.getElementById("roupaPreco").disabled = false;
  document.getElementById("roupaDescricao").value = "";
}

async function registrarInteresse(id) {
  if (!token) {
    toast("Faça login para registrar interesse.");
    mostrarTela("login");
    return;
  }

  try {
    const resposta = await fetch(`${API}/api/clothes/${id}/interest`, {
      method: "POST",
      headers: authHeaders()
    });

    const dados = await respostaJSON(resposta);
    toast(dados.message);
  } catch (erro) {
    toast(erro.message);
  }
}

async function carregarPerfil() {
  document.getElementById("perfilNome").textContent = usuario?.name || "Visitante";
  document.getElementById("perfilEmail").textContent = usuario?.email || "---";
  document.getElementById("perfilPontos").textContent = usuario?.points || 0;

  const lista = document.getElementById("meusAnuncios");

  if (!token) {
    lista.innerHTML = "<p>Entre na sua conta para ver seus anúncios.</p>";
    return;
  }

  try {
    const resposta = await fetch(`${API}/api/my-clothes`, {
      headers: authHeaders()
    });

    const dados = await respostaJSON(resposta);

    if (!dados.clothes.length) {
      lista.innerHTML = "<p>Você ainda não publicou nenhuma roupa.</p>";
      return;
    }

    lista.innerHTML = dados.clothes.map(item => `
      <div class="item-simples">
        <h3>${escapeHTML(item.name)}</h3>
        <p>${item.type} • Tamanho ${escapeHTML(item.size)} • ${escapeHTML(item.condition)}</p>
        <p>Interessados: ${item.interests.length}</p>
        <button class="btn secundario" onclick="apagarRoupa('${item.id}')">Apagar anúncio</button>
      </div>
    `).join("");
  } catch (erro) {
    lista.innerHTML = `<p>${erro.message}</p>`;
  }
}

async function apagarRoupa(id) {
  const confirmar = confirm("Deseja apagar este anúncio?");
  if (!confirmar) return;

  try {
    const resposta = await fetch(`${API}/api/clothes/${id}`, {
      method: "DELETE",
      headers: authHeaders()
    });

    const dados = await respostaJSON(resposta);
    toast(dados.message);
    carregarPerfil();
    carregarIndicadores();
  } catch (erro) {
    toast(erro.message);
  }
}

async function carregarIndicadores() {
  const el = document.getElementById("indicadores");
  if (!el) return;

  try {
    const resposta = await fetch(`${API}/api/stats`);
    const stats = await respostaJSON(resposta);

    el.innerHTML = `
      <div class="indicador"><strong>${stats.totalClothes}</strong><span>roupas cadastradas</span></div>
      <div class="indicador"><strong>${stats.sales}</strong><span>vendas anunciadas</span></div>
      <div class="indicador"><strong>${stats.exchanges}</strong><span>trocas disponíveis</span></div>
      <div class="indicador"><strong>${stats.donations}</strong><span>doações ativas</span></div>
    `;
  } catch {
    el.innerHTML = "";
  }
}

function escapeHTML(texto) {
  return String(texto)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

controlarPreco();
carregarIndicadores();