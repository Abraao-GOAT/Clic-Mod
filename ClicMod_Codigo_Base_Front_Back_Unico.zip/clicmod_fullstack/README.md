# Clic Mod - Front-end + Back-end

Sistema completo do **Clic Mod**, um marketplace de moda circular.

## O que já funciona

- Tela inicial
- Cadastro de usuário
- Login
- Feed de roupas
- Busca de roupas
- Filtro por Venda, Troca e Doação
- Publicar roupa com foto
- Pontos sustentáveis
- Botão "Tenho interesse"
- Perfil do usuário
- Meus anúncios
- Apagar anúncio
- Tela do modelo de negócio

## Como rodar

Você precisa ter o **Node.js** instalado.

1. Extraia o ZIP.
2. Abra a pasta `clicmod_fullstack`.
3. Abra o terminal dentro da pasta.
4. Rode:

```bash
npm start
```

5. Abra no navegador:

```txt
http://localhost:3000
```

## Sem instalar dependências

Este projeto foi feito usando apenas recursos nativos do Node.js.  
Não precisa rodar `npm install`.

## Estrutura

```txt
clicmod_fullstack/
├── server.js
├── package.json
├── data/
│   └── db.json
└── public/
    ├── index.html
    ├── style.css
    └── script.js
```

## Observação para apresentação

O banco de dados está em `data/db.json` para facilitar a demonstração.  
Em uma versão profissional, esse banco poderia virar MySQL, PostgreSQL ou MongoDB.
