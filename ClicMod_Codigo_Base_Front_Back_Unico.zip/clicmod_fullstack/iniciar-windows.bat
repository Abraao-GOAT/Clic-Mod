@echo off
echo Iniciando Clic Mod...
node server.js
pause
